import MiniSearch from 'https://cdn.jsdelivr.net/npm/minisearch@6.1.0/+esm';
import localforage from 'https://cdn.jsdelivr.net/npm/localforage@1.10.0/+esm';

const SYNONYMS = {
  'signin': 'login',
  'sign in': 'login',
  'invoice': 'billing',
  'error': 'bug',
  'credential': 'password',
  'noc': 'certificate',
  'cert': 'certificate',
  'zoom': 'meeting',
  'vibe': 'platform',
  'team': 'group',
  'mentor': 'guide'
};

let miniSearchInstance;
const lf = localforage.createInstance({ name: 'help_search', storeName: 'docs' });

self.onmessage = async (event) => {
  const { type, payload } = event.data;
  const t0 = performance.now();

  if (type === 'INIT') {
    const tInit = performance.now();
    try {
      const response = await fetch(payload.dataEndpoint);
      if (!response.ok) throw new Error(`Failed to fetch: ${response.status}`);
      const documents = await response.json();
      const tFetch = performance.now();

      const documentDictionary = {};
      for (const doc of documents) {
        documentDictionary[doc.id] = doc;
        await lf.setItem(doc.id, doc);
      }

      miniSearchInstance = new MiniSearch({
        idField: 'id',
        fields: ['title', 'content', 'tags'],
        storeFields: ['type'],
        extractField: (document, fieldName) => {
          if (fieldName === 'tags') return document[fieldName].join(' ');
          return document[fieldName];
        },
        searchOptions: {
          boost: { tags: 4, title: 2, content: 1 },
          prefix: true,
          fuzzy: 0.2,
        }
      });

      miniSearchInstance.addAll(documents);
      const tIndex = performance.now();

      self.postMessage({
        type: 'READY',
        timing: {
          fetch_ms: (tFetch - tInit).toFixed(1),
          index_ms: (tIndex - tFetch).toFixed(1),
          total_ms: (tIndex - tInit).toFixed(1),
          doc_count: documents.length
        }
      });
    } catch (error) {
      self.postMessage({ type: 'ERROR', payload: error.message });
    }
  }

  if (type === 'SEARCH') {
    if (!miniSearchInstance) return;

    const tSearch = performance.now();
    let { query } = payload;
    let processedQuery = query.toLowerCase().trim();

    Object.keys(SYNONYMS).forEach(key => {
      if (processedQuery.includes(key)) {
        processedQuery += ` ${SYNONYMS[key]}`;
      }
    });

    const rawMatches = miniSearchInstance.search(processedQuery);
    const topMatches = rawMatches.slice(0, 30);
    const tSearchDone = performance.now();

    const populatedResults = [];
    for (const match of topMatches) {
      const doc = await lf.getItem(match.id);
      if (doc) {
        populatedResults.push({ ...doc, score: match.score });
      }
    }
    const tDone = performance.now();

    self.postMessage({
      type: 'RESULTS',
      payload: populatedResults,
      timing: {
        search_ms: (tSearchDone - tSearch).toFixed(1),
        fetch_docs_ms: (tDone - tSearchDone).toFixed(1),
        total_ms: (tDone - tSearch).toFixed(1)
      }
    });
  }
};